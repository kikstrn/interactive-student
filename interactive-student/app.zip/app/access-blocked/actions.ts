"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function signOutBlockedUser() {
    const supabase = await createClient();

    await supabase.auth.signOut();

    redirect("/login");
}
